/****************************************************************************
**
** Copyright (C) 2006 Trolltech AS. All rights reserved.
**
** This file is part of the documentation of Qt. It was originally
** published as part of Qt Quarterly.
**
** This file may be used under the terms of the GNU General Public License
** version 2.0 as published by the Free Software Foundation or under the
** terms of the Qt Commercial License Agreement. The respective license
** texts for these are provided with the open source and commercial
** editions of Qt.
**
** If you are unsure which license is appropriate for your use, please
** review the following information:
** http://www.trolltech.com/products/qt/licensing.html or contact the
** sales department at sales@trolltech.com.
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
****************************************************************************/

#ifndef _faderwidget_h_
#define _faderwidget_h_

#include <QWidget>

#include "SVWidgetsLib/SVWidgetsLib.h"

class QTimer;

class SVWidgetsLib_EXPORT QtSFaderWidget : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(QColor fadeColor READ fadeColor WRITE setFadeColor)
    Q_PROPERTY(int fadeDuration READ fadeDuration WRITE setFadeDuration)
  public:

    QtSFaderWidget(QWidget* parent);
    virtual ~QtSFaderWidget();

    QColor fadeColor() const { return startColor; }
    void setFadeColor(const QColor& newColor) { startColor = newColor; }

    void setFadeIn();
    void setFadeOut();

    void setStartColor(QColor color);
    QColor getStartColor();

    int fadeDuration() const { return duration; }
    void setFadeDuration(int milliseconds) { duration = milliseconds; }

    void start();

  signals:
    void animationComplete();

  protected:
    void paintEvent(QPaintEvent* event);

  private:
    QTimer* timer;
    QColor startColor;
    int currentAlpha;
    int duration;
    bool fadeIn;
};

#endif
